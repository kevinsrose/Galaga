#ifndef PRESSSTART_BITMAP_H
#define PRESSSTART_BITMAP_H
extern const unsigned short pressStart[9120];
#define PRESSSTART_WIDTH 160
#define PRESSSTART_HEIGHT 57
#endif