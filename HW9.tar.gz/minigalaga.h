#ifndef MINIGALAGA_BITMAP_H
#define MINIGALAGA_BITMAP_H
extern const unsigned short minigalaga[81];
#define MINIGALAGA_WIDTH 9
#define MINIGALAGA_HEIGHT 9
#endif