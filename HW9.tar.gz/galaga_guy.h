#ifndef GALAGA_GUY_BITMAP_H
#define GALAGA_GUY_BITMAP_H
extern const unsigned short galaga_guy[4096];
#define GALAGA_GUY_WIDTH 64
#define GALAGA_GUY_HEIGHT 64
#endif