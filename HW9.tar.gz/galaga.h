#ifndef GALAGA_BITMAP_H
#define GALAGA_BITMAP_H
extern const unsigned short galaga[380];
#define GALAGA_WIDTH 19
#define GALAGA_HEIGHT 20
#endif