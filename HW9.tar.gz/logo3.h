#ifndef LOGO3_BITMAP_H
#define LOGO3_BITMAP_H
extern const unsigned short logo3[5200];
#define LOGO3_WIDTH 100
#define LOGO3_HEIGHT 52
#endif