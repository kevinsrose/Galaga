extern const unsigned short fontdata_6x8[12288];

void drawChar(int, int, char, unsigned short);
void drawString(int, int, char *str, unsigned short);