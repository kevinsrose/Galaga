#ifndef LOGO2_BITMAP_H
#define LOGO2_BITMAP_H
extern const unsigned short logo2[5200];
#define LOGO2_WIDTH 100
#define LOGO2_HEIGHT 52
#endif