Welcome to Galaga!!

Press & Hold Start (Enter) to begin the game.
Use the arrow keys to move and A (Z) to shoot.
Press backspace to go back to the start screen.
Game ends when you destroy all 6 enemies!