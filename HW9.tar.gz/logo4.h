#ifndef LOGO4_BITMAP_H
#define LOGO4_BITMAP_H
extern const unsigned short logo4[5200];
#define LOGO4_WIDTH 100
#define LOGO4_HEIGHT 52
#endif