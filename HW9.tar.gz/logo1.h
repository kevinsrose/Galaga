#ifndef LOGO1_BITMAP_H
#define LOGO1_BITMAP_H
extern const unsigned short logo1[5200];
#define LOGO1_WIDTH 100
#define LOGO1_HEIGHT 52
#endif